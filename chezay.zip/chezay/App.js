
import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  Alert,
  Image,
  ImageBackground,
} from 'react-native';

export default function App() {
  const [screen, setScreen] = useState('splash');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState('Admin');

  // CUSTOMER STATES
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState([]);
  const [splitCount, setSplitCount] = useState('1');

  useEffect(() => {
    const timer = setTimeout(() => {
      setScreen('login');
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const navigate = (target) => {
    setScreen(target);
  };

  const goToHome = () => {
    setScreen('login');
    setSelectedCategory('All');
    setCart([]);
    setSplitCount('1');
    setUsername('');
    setPassword('');
    setSelectedRole('Admin');
  };

  const resetCustomerFlow = () => {
    setSelectedCategory('All');
    setCart([]);
    setSplitCount('1');
  };

  const handleLogin = () => {
    if (selectedRole === 'Admin') {
      navigate('dashboard');
    } else {
      navigate('customerMenu');
    }
  };

  const handleGuestLogin = () => {
    setSelectedRole('Guest');
    navigate('customerMenu');
  };

  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((cartItem) => cartItem.id === item.id);

      if (existing) {
        return prev.map((cartItem) =>
          cartItem.id === item.id
            ? { ...cartItem, qty: cartItem.qty + 1 }
            : cartItem
        );
      }

      return [...prev, { ...item, qty: 1 }];
    });

    Alert.alert('Added to Cart', `${item.name} has been successfully added to your cart.`);
  };

  const increaseQty = (id) => {
    setCart((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, qty: item.qty + 1 } : item
      )
    );
  };

  const decreaseQty = (id) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.id === id ? { ...item, qty: item.qty - 1 } : item
        )
        .filter((item) => item.qty > 0)
    );
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  }, [cart]);

  if (screen === 'splash') {
    return <SplashScreen />;
  }

  if (screen === 'login') {
    return (
      <LoginScreen
        username={username}
        setUsername={setUsername}
        password={password}
        setPassword={setPassword}
        selectedRole={selectedRole}
        setSelectedRole={setSelectedRole}
        onLogin={handleLogin}
        onGuestLogin={handleGuestLogin}
      />
    );
  }

  // =========================
  // ADMIN FLOW (UNCHANGED)
  // =========================
  if (screen === 'dashboard') {
    return <DashboardScreen navigate={navigate} selectedRole={selectedRole} />;
  }

  if (screen === 'orders') {
    return <OrdersScreen navigate={navigate} />;
  }

  if (screen === 'tables') {
    return <TablesScreen navigate={navigate} />;
  }

  if (screen === 'menu') {
    return <MenuScreen navigate={navigate} />;
  }

  if (screen === 'reservations') {
    return <ReservationsScreen navigate={navigate} />;
  }

  if (screen === 'billing') {
    return <BillingScreen navigate={navigate} />;
  }

  if (screen === 'inventory') {
    return <InventoryScreen navigate={navigate} />;
  }

  if (screen === 'reports') {
    return <ReportsScreen navigate={navigate} />;
  }

  if (screen === 'settings') {
    return (
      <SettingsScreen
        navigate={navigate}
        onLogout={() => {
          resetCustomerFlow();
          navigate('login');
        }}
        username={username}
        selectedRole={selectedRole}
      />
    );
  }

  // =========================
  // CUSTOMER FLOW
  // =========================
  if (screen === 'customerMenu') {
    return (
      <CustomerMenuScreen
        navigate={navigate}
        goToHome={goToHome}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        addToCart={addToCart}
        cartCount={cart.reduce((sum, item) => sum + item.qty, 0)}
      />
    );
  }

  if (screen === 'customerCart') {
    return (
      <CustomerCartScreen
        navigate={navigate}
        goToHome={goToHome}
        cart={cart}
        cartTotal={cartTotal}
        increaseQty={increaseQty}
        decreaseQty={decreaseQty}
        splitCount={splitCount}
        setSplitCount={setSplitCount}
      />
    );
  }

  if (screen === 'customerReserve') {
    return <CustomerReserveScreen navigate={navigate} goToHome={goToHome} />;
  }

  if (screen === 'customerFeedback') {
    return <CustomerFeedbackScreen navigate={navigate} goToHome={goToHome} />;
  }

  if (screen === 'customerQR') {
    return <CustomerQRScreen navigate={navigate} goToHome={goToHome} />;
  }

  return null;
}

function SplashScreen() {
  return (
    <SafeAreaView style={styles.splashContainer}>
      <StatusBar barStyle="light-content" />
      <Text style={styles.logo}>🍽</Text>
      <Text style={styles.splashTitle}>CheZay</Text>
      <Text style={styles.splashSubtitle}>A refined dining experience</Text>
    </SafeAreaView>
  );
}

function LoginScreen({
  username,
  setUsername,
  password,
  setPassword,
  selectedRole,
  setSelectedRole,
  onLogin,
  onGuestLogin,
}) {
  return (
    <ImageBackground
      source={{
        uri: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1200&auto=format&fit=crop',
      }}
      style={styles.loginBackground}
    >
      <SafeAreaView style={styles.loginOverlay}>
        <ScrollView contentContainerStyle={styles.loginWrapper}>
          <Text style={styles.brandIcon}>🍽</Text>
          <Text style={styles.brandTitleLight}>CheZay</Text>
          <Text style={styles.brandSubtitleLight}>
            Where Every Plate Tells a Story
          </Text>

          <View style={styles.formCardGlass}>
            <View style={styles.roleContainer}>
              <TouchableOpacity
                style={[
                  styles.roleButton,
                  selectedRole === 'Admin' && styles.roleButtonActive,
                ]}
                onPress={() => setSelectedRole('Admin')}
              >
                <Text
                  style={[
                    styles.roleButtonText,
                    selectedRole === 'Admin' && styles.roleButtonTextActive,
                  ]}
                >
                  Admin
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.roleButton,
                  selectedRole === 'Sign In' && styles.roleButtonActive,
                ]}
                onPress={() => setSelectedRole('Sign In')}
              >
                <Text
                  style={[
                    styles.roleButtonText,
                    selectedRole === 'Sign In' && styles.roleButtonTextActive,
                  ]}
                >
                  Sign In
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.roleButton,
                  selectedRole === 'Guest' && styles.roleButtonActive,
                ]}
                onPress={() => setSelectedRole('Guest')}
              >
                <Text
                  style={[
                    styles.roleButtonText,
                    selectedRole === 'Guest' && styles.roleButtonTextActive,
                  ]}
                >
                  Guest
                </Text>
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.input}
              placeholder="Email or username"
              placeholderTextColor="#888"
              value={username}
              onChangeText={setUsername}
            />

            <TextInput
              style={styles.input}
              placeholder="Password"
              placeholderTextColor="#888"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />

            <TouchableOpacity style={styles.primaryButton} onPress={onLogin}>
              <Text style={styles.primaryButtonText}>
                {selectedRole === 'Sign In' ? 'Sign In' : `Continue as ${selectedRole}`}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.guestButton} onPress={onGuestLogin}>
              <Text style={styles.guestButtonText}>Browse as Guest</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

// =========================
// ADMIN SCREENS (UNCHANGED)
// =========================

function DashboardScreen({ navigate, selectedRole }) {
  const stats = [
    { title: 'Orders Today', value: '24' },
    { title: 'Revenue', value: 'Rs. 18,500' },
    { title: 'Available Tables', value: '6' },
    { title: 'Pending Reservations', value: '4' },
  ];

  const recentOrders = [
    { id: '1', table: 'Table 2', status: 'Preparing', amount: 'Rs. 2,100' },
    { id: '2', table: 'Table 5', status: 'Served', amount: 'Rs. 1,250' },
    { id: '3', table: 'Table 1', status: 'Pending', amount: 'Rs. 3,400' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Dashboard" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.welcomeText}>Welcome back, {selectedRole} 👋</Text>
        <Text style={styles.sectionSubtitle}>Manage CheZay efficiently</Text>

        <View style={styles.statsGrid}>
          {stats.map((item, index) => (
            <View key={index} style={styles.statCard}>
              <Text style={styles.statValue}>{item.value}</Text>
              <Text style={styles.statTitle}>{item.title}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <QuickButton title="Orders" onPress={() => navigate('orders')} />
          <QuickButton title="Tables" onPress={() => navigate('tables')} />
          <QuickButton title="Menu" onPress={() => navigate('menu')} />
          <QuickButton title="Billing" onPress={() => navigate('billing')} />
          <QuickButton title="Reserve" onPress={() => navigate('reservations')} />
          <QuickButton title="Reports" onPress={() => navigate('reports')} />
        </View>

        <Text style={styles.sectionTitle}>Recent Orders</Text>
        {recentOrders.map((order) => (
          <View key={order.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>{order.table}</Text>
              <Text style={styles.cardSub}>Order #{order.id}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.cardAmount}>{order.amount}</Text>
              <Text style={styles.statusPending}>{order.status}</Text>
            </View>
          </View>
        ))}
      </ScrollView>

      <BottomNav navigate={navigate} current="dashboard" />
    </SafeAreaView>
  );
}

function OrdersScreen({ navigate }) {
  const orders = [
    { id: '101', table: 'Table 1', items: '3 items', amount: 'Rs. 1,450', status: 'Pending' },
    { id: '102', table: 'Table 4', items: '5 items', amount: 'Rs. 2,850', status: 'Preparing' },
    { id: '103', table: 'Table 2', items: '2 items', amount: 'Rs. 950', status: 'Served' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Orders Management" />
      <ScrollView>
        <TextInput style={styles.searchInput} placeholder="Search orders..." placeholderTextColor="#888" />
        {orders.map((order) => (
          <View key={order.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>Order #{order.id}</Text>
              <Text style={styles.cardSub}>{order.table} • {order.items}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.cardAmount}>{order.amount}</Text>
              <Text style={styles.statusBadge}>{order.status}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="orders" />
    </SafeAreaView>
  );
}

function TablesScreen({ navigate }) {
  const tables = [
    { id: '1', name: 'Table 1', status: 'Available' },
    { id: '2', name: 'Table 2', status: 'Occupied' },
    { id: '3', name: 'Table 3', status: 'Reserved' },
    { id: '4', name: 'Table 4', status: 'Available' },
    { id: '5', name: 'Table 5', status: 'Cleaning' },
    { id: '6', name: 'Table 6', status: 'Occupied' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Table Management" />
      <ScrollView contentContainerStyle={styles.gridContainer}>
        {tables.map((table) => (
          <View key={table.id} style={styles.tableCard}>
            <Text style={styles.tableTitle}>{table.name}</Text>
            <Text
              style={[
                styles.tableStatus,
                table.status === 'Available' && styles.available,
                table.status === 'Occupied' && styles.occupied,
                table.status === 'Reserved' && styles.reserved,
                table.status === 'Cleaning' && styles.cleaning,
              ]}
            >
              {table.status}
            </Text>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="tables" />
    </SafeAreaView>
  );
}

function MenuScreen({ navigate }) {
  const menuItems = [
    { id: '1', name: 'Grilled Chicken', category: 'Main Course', price: 'Rs. 1,200' },
    { id: '2', name: 'Cheese Pasta', category: 'Main Course', price: 'Rs. 950' },
    { id: '3', name: 'Chocolate Cake', category: 'Dessert', price: 'Rs. 550' },
    { id: '4', name: 'Mint Mojito', category: 'Drinks', price: 'Rs. 350' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Menu Management" />
      <ScrollView>
        <TextInput style={styles.searchInput} placeholder="Search menu item..." placeholderTextColor="#888" />
        {menuItems.map((item) => (
          <View key={item.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.cardSub}>{item.category}</Text>
            </View>
            <Text style={styles.cardAmount}>{item.price}</Text>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="menu" />
    </SafeAreaView>
  );
}

function ReservationsScreen({ navigate }) {
  const reservations = [
    { id: '1', name: 'Ali Khan', guests: '4 Guests', time: '7:30 PM', status: 'Confirmed' },
    { id: '2', name: 'Sara Ahmed', guests: '2 Guests', time: '8:00 PM', status: 'Pending' },
    { id: '3', name: 'Hamza Noor', guests: '6 Guests', time: '9:15 PM', status: 'Confirmed' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Reservations" />
      <ScrollView>
        {reservations.map((res) => (
          <View key={res.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>{res.name}</Text>
              <Text style={styles.cardSub}>{res.guests} • {res.time}</Text>
            </View>
            <Text style={styles.statusBadge}>{res.status}</Text>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="reservations" />
    </SafeAreaView>
  );
}

function BillingScreen({ navigate }) {
  const billItems = [
    { id: '1', item: 'Grilled Chicken', qty: 2, price: 'Rs. 2,400' },
    { id: '2', item: 'Mint Mojito', qty: 2, price: 'Rs. 700' },
    { id: '3', item: 'Chocolate Cake', qty: 1, price: 'Rs. 550' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Billing & Payment" />
      <ScrollView>
        {billItems.map((bill) => (
          <View key={bill.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>{bill.item}</Text>
              <Text style={styles.cardSub}>Qty: {bill.qty}</Text>
            </View>
            <Text style={styles.cardAmount}>{bill.price}</Text>
          </View>
        ))}

        <View style={styles.totalCard}>
          <Text style={styles.totalText}>Subtotal: Rs. 3,650</Text>
          <Text style={styles.totalText}>Tax: Rs. 350</Text>
          <Text style={styles.grandTotal}>Total: Rs. 4,000</Text>

          <TouchableOpacity style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>Generate Receipt</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      <BottomNav navigate={navigate} current="billing" />
    </SafeAreaView>
  );
}

function InventoryScreen({ navigate }) {
  const stock = [
    { id: '1', item: 'Chicken', qty: '12 kg', status: 'Available' },
    { id: '2', item: 'Cheese', qty: '2 kg', status: 'Low Stock' },
    { id: '3', item: 'Rice', qty: '18 kg', status: 'Available' },
    { id: '4', item: 'Soft Drinks', qty: '8 bottles', status: 'Low Stock' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Inventory Management" />
      <ScrollView>
        {stock.map((s) => (
          <View key={s.id} style={styles.listCard}>
            <View>
              <Text style={styles.cardTitle}>{s.item}</Text>
              <Text style={styles.cardSub}>{s.qty}</Text>
            </View>
            <Text style={s.status === 'Low Stock' ? styles.lowStock : styles.available}>
              {s.status}
            </Text>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="inventory" />
    </SafeAreaView>
  );
}

function ReportsScreen({ navigate }) {
  const reports = [
    { label: 'Daily Sales', value: 'Rs. 18,500' },
    { label: 'Weekly Sales', value: 'Rs. 122,000' },
    { label: 'Monthly Revenue', value: 'Rs. 485,000' },
    { label: 'Best Seller', value: 'Grilled Chicken' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Reports & Analytics" />
      <ScrollView>
        {reports.map((report, index) => (
          <View key={index} style={styles.statCardWide}>
            <Text style={styles.statTitle}>{report.label}</Text>
            <Text style={styles.statValue}>{report.value}</Text>
          </View>
        ))}
      </ScrollView>
      <BottomNav navigate={navigate} current="reports" />
    </SafeAreaView>
  );
}

function SettingsScreen({ navigate, onLogout, username, selectedRole }) {
  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Settings & Profile" />
      <ScrollView>
        <View style={styles.profileCard}>
          <Text style={styles.profileName}>{username ? username : 'Guest User'}</Text>
          <Text style={styles.profileRole}>{selectedRole}</Text>
        </View>

        <View style={styles.listCard}>
          <Text style={styles.cardTitle}>Notifications</Text>
          <Text style={styles.cardSub}>Enabled</Text>
        </View>

        <View style={styles.listCard}>
          <Text style={styles.cardTitle}>Theme</Text>
          <Text style={styles.cardSub}>Light Mode</Text>
        </View>

        <TouchableOpacity style={styles.logoutButton} onPress={onLogout}>
          <Text style={styles.primaryButtonText}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>
      <BottomNav navigate={navigate} current="settings" />
    </SafeAreaView>
  );
}

// =========================
// CUSTOMER MENU
// =========================

function CustomerMenuScreen({
  navigate,
  goToHome,
  selectedCategory,
  setSelectedCategory,
  addToCart,
  cartCount,
}) {
  const categories = ['All', 'Desi', 'Continental', 'Fast Food', 'Desserts', 'Drinks'];

  const menuItems = [
    {
      id: 'c1',
      name: 'Chicken Karahi',
      category: 'Desi',
      price: 1450,
      displayPrice: 'Rs. 1,450',
      image:
        'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c2',
      name: 'Biryani',
      category: 'Desi',
      price: 650,
      displayPrice: 'Rs. 650',
      image:
        'https://images.unsplash.com/photo-1589302168068-964664d93dc0?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c3',
      name: 'Alfredo Pasta',
      category: 'Continental',
      price: 1100,
      displayPrice: 'Rs. 1,100',
      image:
        'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c4',
      name: 'Grilled Steak',
      category: 'Continental',
      price: 2200,
      displayPrice: 'Rs. 2,200',
      image:
        'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c5',
      name: 'Zinger Burger',
      category: 'Fast Food',
      price: 850,
      displayPrice: 'Rs. 850',
      image:
        'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c6',
      name: 'Loaded Fries',
      category: 'Fast Food',
      price: 550,
      displayPrice: 'Rs. 550',
      image:
        'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c7',
      name: 'Chocolate Lava Cake',
      category: 'Desserts',
      price: 650,
      displayPrice: 'Rs. 650',
      image:
        'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c8',
      name: 'Cheesecake',
      category: 'Desserts',
      price: 700,
      displayPrice: 'Rs. 700',
      image:
        'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c9',
      name: 'Mint Margarita',
      category: 'Drinks',
      price: 350,
      displayPrice: 'Rs. 350',
      image:
        'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=1200&auto=format&fit=crop',
    },
    {
      id: 'c10',
      name: 'Cold Coffee',
      category: 'Drinks',
      price: 450,
      displayPrice: 'Rs. 450',
      image:
        'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?q=80&w=1200&auto=format&fit=crop',
    },
  ];

  const filteredItems =
    selectedCategory === 'All'
      ? menuItems
      : menuItems.filter((item) => item.category === selectedCategory);

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="CheZay Menu" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.customerTopBar}>
          <Text style={styles.welcomeText}>Welcome 🍽</Text>
          <TouchableOpacity style={styles.homeMiniButton} onPress={goToHome}>
            <Text style={styles.homeMiniButtonText}>Home</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.customerTagline}>
          Discover today’s favorites, chef specials, and signature flavors.
        </Text>

        <TouchableOpacity
          style={styles.viewCartBanner}
          onPress={() => navigate('customerCart')}
        >
          <Text style={styles.viewCartBannerText}>
            View Cart ({cartCount})
          </Text>
        </TouchableOpacity>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoryRow}
        >
          {categories.map((category) => (
            <TouchableOpacity
              key={category}
              style={[
                styles.categoryChip,
                selectedCategory === category && styles.categoryChipActive,
              ]}
              onPress={() => setSelectedCategory(category)}
            >
              <Text
                style={[
                  styles.categoryChipText,
                  selectedCategory === category && styles.categoryChipTextActive,
                ]}
              >
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={styles.sectionTitle}>Our Signature Menu</Text>

        {filteredItems.map((item) => (
          <View key={item.id} style={styles.foodCard}>
            <Image source={{ uri: item.image }} style={styles.foodImage} />
            <View style={styles.foodContent}>
              <Text style={styles.foodTitle}>{item.name}</Text>
              <Text style={styles.foodCategory}>{item.category}</Text>
              <Text style={styles.foodPrice}>{item.displayPrice}</Text>

              <TouchableOpacity
                style={styles.addCartButton}
                onPress={() => addToCart(item)}
              >
                <Text style={styles.addCartButtonText}>Add to Cart</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>

      <CustomerBottomNav navigate={navigate} current="customerMenu" cartCount={cartCount} />
    </SafeAreaView>
  );
}

function CustomerCartScreen({
  navigate,
  goToHome,
  cart,
  cartTotal,
  increaseQty,
  decreaseQty,
  splitCount,
  setSplitCount,
}) {
  const splitNumber = parseInt(splitCount) || 1;
  const finalTotal = cartTotal + 200;
  const splitAmount = finalTotal / splitNumber;

  const getSuggestion = (itemName) => {
    const suggestions = {
      'Chicken Karahi': 'This pairs beautifully with Mint Margarita.',
      'Biryani': 'Cold Coffee would go really well with this.',
      'Alfredo Pasta': 'Try Cheesecake after this for a complete meal.',
      'Grilled Steak': 'Mint Margarita would be a great pairing.',
      'Zinger Burger': 'Loaded Fries and Cold Coffee make a perfect combo.',
      'Loaded Fries': 'Cold Coffee would be a delicious match.',
      'Chocolate Lava Cake': 'Mint Margarita adds a refreshing contrast.',
      'Cheesecake': 'Cold Coffee would pair wonderfully with this.',
      'Mint Margarita': 'A refreshing addition to any main course.',
      'Cold Coffee': 'A perfect drink to go with desserts and burgers.',
    };

    return suggestions[itemName] || 'Great choice! Our chef recommends pairing this with a refreshing drink.';
  };

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Your Cart" />
      <ScrollView>
        <View style={styles.customerTopBar}>
          <TouchableOpacity style={styles.homeMiniButton} onPress={() => navigate('customerMenu')}>
            <Text style={styles.homeMiniButtonText}>Back</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.homeMiniButton} onPress={goToHome}>
            <Text style={styles.homeMiniButtonText}>Home</Text>
          </TouchableOpacity>
        </View>

        {cart.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Your cart is empty</Text>
            <Text style={styles.cardSub}>Add some delicious items from CheZay menu</Text>
          </View>
        ) : (
          <>
            {cart.map((item) => (
              <View key={item.id} style={styles.listCard}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cardTitle}>{item.name}</Text>
                  <Text style={styles.cardSub}>
                    Rs. {item.price} × {item.qty}
                  </Text>
                  <Text style={[styles.cardAmount, { marginTop: 6 }]}>
                    Rs. {item.price * item.qty}
                  </Text>

                  <View style={styles.aiSuggestionBox}>
                    <Text style={styles.aiSuggestionTitle}>CheZay Suggestion</Text>
                    <Text style={styles.aiSuggestionText}>
                      You ordered {item.name}. {getSuggestion(item.name)}
                    </Text>
                  </View>
                </View>

                <View style={styles.qtyControl}>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => decreaseQty(item.id)}>
                    <Text style={styles.qtyBtnText}>−</Text>
                  </TouchableOpacity>
                  <Text style={styles.qtyNumber}>{item.qty}</Text>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => increaseQty(item.id)}>
                    <Text style={styles.qtyBtnText}>+</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}

            <View style={styles.totalCard}>
              <Text style={styles.totalText}>Items Total: Rs. {cartTotal}</Text>
              <Text style={styles.totalText}>Service Charges: Rs. 200</Text>
              <Text style={styles.grandTotal}>Total Bill: Rs. {finalTotal}</Text>

              <Text style={styles.label}>Split Bill</Text>
              <TextInput
                style={styles.input}
                keyboardType="numeric"
                placeholder="Enter number of people"
                placeholderTextColor="#888"
                value={splitCount}
                onChangeText={setSplitCount}
              />

              <Text style={styles.splitText}>
                Per Person: Rs. {splitAmount.toFixed(0)}
              </Text>

              <TouchableOpacity
                style={styles.primaryButton}
                onPress={() => Alert.alert('Payment Successful', 'Your bill has been paid successfully.')}
              >
                <Text style={styles.primaryButtonText}>Pay Full Bill</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.secondaryButton}
                onPress={() =>
                  Alert.alert(
                    'Split Bill Ready',
                    `Your bill has been split successfully. Each person pays Rs. ${splitAmount.toFixed(0)}.`
                  )
                }
              >
                <Text style={styles.secondaryButtonText}>Split Bill</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>

      <CustomerBottomNav navigate={navigate} current="customerCart" cartCount={cart.length} />
    </SafeAreaView>
  );
}

function CustomerReserveScreen({ navigate, goToHome }) {
  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Reserve Table" />
      <ScrollView>
        <View style={styles.customerTopBar}>
          <TouchableOpacity style={styles.homeMiniButton} onPress={() => navigate('customerMenu')}>
            <Text style={styles.homeMiniButtonText}>Back</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.homeMiniButton} onPress={goToHome}>
            <Text style={styles.homeMiniButtonText}>Home</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.formCard}>
          <Text style={styles.label}>Customer Name</Text>
          <TextInput style={styles.input} placeholder="Enter your name" placeholderTextColor="#888" />

          <Text style={styles.label}>Guests</Text>
          <TextInput style={styles.input} placeholder="Number of guests" placeholderTextColor="#888" />

          <Text style={styles.label}>Date</Text>
          <TextInput style={styles.input} placeholder="Select date" placeholderTextColor="#888" />

          <Text style={styles.label}>Time</Text>
          <TextInput style={styles.input} placeholder="Select time" placeholderTextColor="#888" />

          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => Alert.alert('Reservation Submitted', 'Your reservation request has been submitted successfully.')}
          >
            <Text style={styles.primaryButtonText}>Reserve Now</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <CustomerBottomNav navigate={navigate} current="customerReserve" cartCount={0} />
    </SafeAreaView>
  );
}

function CustomerFeedbackScreen({ navigate, goToHome }) {
  const [feedbackText, setFeedbackText] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="Customer Feedback" />
      <ScrollView>
        <View style={styles.customerTopBar}>
          <TouchableOpacity style={styles.homeMiniButton} onPress={() => navigate('customerMenu')}>
            <Text style={styles.homeMiniButtonText}>Back</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.homeMiniButton} onPress={goToHome}>
            <Text style={styles.homeMiniButtonText}>Home</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.formCard}>
          <Text style={styles.label}>Your Feedback</Text>
          <TextInput
            style={styles.feedbackInput}
            placeholder="Tell us about your experience at CheZay..."
            placeholderTextColor="#888"
            multiline
            value={feedbackText}
            onChangeText={setFeedbackText}
          />

          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => {
              setFeedbackText('');
              Alert.alert('Feedback Received', 'Thank you so much for your feedback.');
            }}
          >
            <Text style={styles.primaryButtonText}>Submit Feedback</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <CustomerBottomNav navigate={navigate} current="customerFeedback" cartCount={0} />
    </SafeAreaView>
  );
}

function CustomerQRScreen({ navigate, goToHome }) {
  return (
    <SafeAreaView style={styles.container}>
      <AppHeader title="CheZay QR Access" />
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        <View style={styles.customerTopBar}>
          <TouchableOpacity style={styles.homeMiniButton} onPress={() => navigate('customerMenu')}>
            <Text style={styles.homeMiniButtonText}>Back</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.homeMiniButton} onPress={goToHome}>
            <Text style={styles.homeMiniButtonText}>Home</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.qrCard}>
          <Text style={styles.qrTitle}>Scan for Quick Access</Text>
          <Image
            source={{
              uri: 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=https://chezay-restaurant-demo.com',
            }}
            style={styles.qrImage}
          />
          <Text style={styles.qrText}>
            Scan this QR to access menu, reservation details, and restaurant information.
          </Text>
        </View>
      </ScrollView>

      <CustomerBottomNav navigate={navigate} current="customerQR" cartCount={0} />
    </SafeAreaView>
  );
}

// =========================
// REUSABLE COMPONENTS
// =========================

function AppHeader({ title }) {
  return (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>{title}</Text>
    </View>
  );
}

function QuickButton({ title, onPress }) {
  return (
    <TouchableOpacity style={styles.quickButton} onPress={onPress}>
      <Text style={styles.quickButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

function BottomNav({ navigate, current }) {
  const items = [
    { key: 'dashboard', label: 'Home' },
    { key: 'orders', label: 'Orders' },
    { key: 'tables', label: 'Tables' },
    { key: 'menu', label: 'Menu' },
    { key: 'settings', label: 'Settings' },
  ];

  return (
    <View style={styles.bottomNav}>
      {items.map((item) => (
        <TouchableOpacity key={item.key} onPress={() => navigate(item.key)}>
          <Text style={[styles.navText, current === item.key && styles.navActive]}>
            {item.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

function CustomerBottomNav({ navigate, current, cartCount }) {
  const items = [
    { key: 'customerMenu', label: 'Menu' },
    { key: 'customerCart', label: `Cart (${cartCount})` },
    { key: 'customerReserve', label: 'Reserve' },
    { key: 'customerFeedback', label: 'Feedback' },
    { key: 'customerQR', label: 'QR' },
  ];

  return (
    <View style={styles.bottomNav}>
      {items.map((item) => (
        <TouchableOpacity key={item.key} onPress={() => navigate(item.key)}>
          <Text style={[styles.navText, current === item.key && styles.navActive]}>
            {item.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

// =========================
// STYLES
// =========================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F5F0',
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  splashContainer: {
    flex: 1,
    backgroundColor: '#1F4D3A',
    justifyContent: 'center',
    alignItems: 'center',
  },

  logo: {
    fontSize: 70,
    marginBottom: 20,
  },

  splashTitle: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#D4AF37',
    letterSpacing: 1,
  },

  splashSubtitle: {
    fontSize: 16,
    color: '#F8F5F0',
    marginTop: 10,
  },

  loginBackground: {
    flex: 1,
  },

  loginOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
  },

  loginWrapper: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingVertical: 30,
    paddingHorizontal: 18,
  },

  brandIcon: {
    fontSize: 52,
    textAlign: 'center',
    marginBottom: 12,
  },

  brandTitleLight: {
    fontSize: 34,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
  },

  brandSubtitleLight: {
    fontSize: 16,
    color: '#F8F5F0',
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 28,
    fontStyle: 'italic',
  },

  formCardGlass: {
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderRadius: 22,
    padding: 20,
  },

  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 20,
  },

  label: {
    fontSize: 14,
    color: '#1E1E1E',
    marginBottom: 8,
    fontWeight: '600',
  },

  input: {
    backgroundColor: '#F3F4F6',
    padding: 15,
    borderRadius: 14,
    marginBottom: 18,
    fontSize: 15,
    color: '#1E1E1E',
  },

  feedbackInput: {
    backgroundColor: '#F3F4F6',
    padding: 15,
    borderRadius: 14,
    marginBottom: 18,
    fontSize: 15,
    color: '#1E1E1E',
    height: 140,
    textAlignVertical: 'top',
  },

  roleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    flexWrap: 'wrap',
  },

  roleButton: {
    width: '31%',
    backgroundColor: '#F3F4F6',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },

  roleButtonActive: {
    backgroundColor: '#1F4D3A',
    borderColor: '#1F4D3A',
  },

  roleButtonText: {
    color: '#1E1E1E',
    fontWeight: '600',
    fontSize: 14,
  },

  roleButtonTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  primaryButton: {
    backgroundColor: '#1F4D3A',
    padding: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 10,
  },

  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  secondaryButton: {
    backgroundColor: '#D4AF37',
    padding: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 12,
  },

  secondaryButtonText: {
    color: '#1E1E1E',
    fontSize: 16,
    fontWeight: 'bold',
  },

  guestButton: {
    marginTop: 14,
    alignItems: 'center',
  },

  guestButtonText: {
    color: '#1F4D3A',
    fontSize: 15,
    fontWeight: 'bold',
  },

  header: {
    paddingVertical: 15,
  },

  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F4D3A',
  },

  welcomeText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1E1E1E',
    marginTop: 5,
  },

  customerTagline: {
    color: '#6B7280',
    marginTop: 5,
    marginBottom: 18,
    fontSize: 14,
    lineHeight: 22,
  },

  sectionSubtitle: {
    color: '#6B7280',
    marginTop: 5,
    marginBottom: 18,
    fontSize: 14,
  },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  statCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 18,
    marginBottom: 14,
  },

  statCardWide: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 20,
    marginBottom: 14,
  },

  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1F4D3A',
  },

  statTitle: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 6,
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E1E1E',
    marginTop: 16,
    marginBottom: 14,
  },

  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  quickButton: {
    width: '48%',
    backgroundColor: '#D4AF37',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 12,
  },

  quickButtonText: {
    color: '#1E1E1E',
    fontWeight: 'bold',
    fontSize: 15,
  },

  listCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 18,
    marginBottom: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  cardTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#1E1E1E',
  },

  cardSub: {
    fontSize: 13,
    color: '#6B7280',
    marginTop: 5,
  },

  cardAmount: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1F4D3A',
  },

  statusBadge: {
    marginTop: 6,
    color: '#D4AF37',
    fontWeight: 'bold',
    fontSize: 13,
  },

  statusPending: {
    marginTop: 6,
    color: '#D4AF37',
    fontWeight: 'bold',
    fontSize: 13,
  },

  searchInput: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 14,
    marginBottom: 18,
    fontSize: 15,
    color: '#1E1E1E',
  },

  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingBottom: 100,
  },

  tableCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 22,
    marginBottom: 14,
    alignItems: 'center',
  },

  tableTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E1E1E',
    marginBottom: 10,
  },

  tableStatus: {
    fontWeight: 'bold',
    fontSize: 14,
  },

  available: {
    color: 'green',
  },

  occupied: {
    color: 'red',
  },

  reserved: {
    color: '#D4AF37',
  },

  cleaning: {
    color: 'gray',
  },

  lowStock: {
    color: 'red',
    fontWeight: 'bold',
  },

  totalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 22,
    marginTop: 10,
    marginBottom: 100,
  },

  totalText: {
    fontSize: 16,
    color: '#1E1E1E',
    marginBottom: 10,
  },

  grandTotal: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F4D3A',
    marginTop: 8,
    marginBottom: 20,
  },

  splitText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#D4AF37',
    marginBottom: 10,
  },

  profileCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 16,
  },

  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1E1E1E',
  },

  profileRole: {
    fontSize: 15,
    color: '#6B7280',
    marginTop: 6,
  },

  logoutButton: {
    backgroundColor: '#B91C1C',
    padding: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 14,
    marginBottom: 100,
  },

  bottomNav: {
    position: 'absolute',
    bottom: 12,
    left: 18,
    right: 18,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    elevation: 8,
  },

  navText: {
    color: '#6B7280',
    fontWeight: '600',
    fontSize: 12,
    textAlign: 'center',
    maxWidth: 70,
  },

  navActive: {
    color: '#1F4D3A',
    fontWeight: 'bold',
  },

  categoryRow: {
    paddingBottom: 8,
    paddingRight: 10,
  },

  categoryChip: {
    backgroundColor: '#F3F4F6',
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 30,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },

  categoryChipActive: {
    backgroundColor: '#1F4D3A',
    borderColor: '#1F4D3A',
  },

  categoryChipText: {
    color: '#1E1E1E',
    fontWeight: '600',
  },

  categoryChipTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  foodCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    marginBottom: 18,
    overflow: 'hidden',
  },

  foodImage: {
    width: '100%',
    height: 190,
  },

  foodContent: {
    padding: 18,
  },

  foodTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E1E1E',
  },

  foodCategory: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 6,
  },

  foodPrice: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#1F4D3A',
    marginTop: 10,
    marginBottom: 14,
  },

  addCartButton: {
    backgroundColor: '#D4AF37',
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 14,
    alignItems: 'center',
  },

  addCartButtonText: {
    color: '#1E1E1E',
    fontWeight: 'bold',
    fontSize: 14,
  },

  emptyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 100,
  },

  emptyTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1E1E1E',
    marginBottom: 10,
  },

  qtyControl: {
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 14,
  },

  qtyBtn: {
    backgroundColor: '#1F4D3A',
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },

  qtyBtnText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },

  qtyNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E1E1E',
    marginVertical: 8,
  },

  qrCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 28,
    alignItems: 'center',
    marginTop: 30,
  },

  qrTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F4D3A',
    marginBottom: 20,
  },

  qrText: {
    fontSize: 15,
    color: '#6B7280',
    marginTop: 18,
    textAlign: 'center',
    lineHeight: 22,
  },

  qrImage: {
    width: 220,
    height: 220,
    borderRadius: 14,
  },

  customerTopBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  homeMiniButton: {
    backgroundColor: '#1F4D3A',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
  },

  homeMiniButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 13,
  },

  viewCartBanner: {
    backgroundColor: '#D4AF37',
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 16,
    marginBottom: 16,
    alignItems: 'center',
  },

  viewCartBannerText: {
    color: '#1E1E1E',
    fontWeight: 'bold',
    fontSize: 15,
  },

  aiSuggestionBox: {
    marginTop: 12,
    backgroundColor: '#F8F5F0',
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E8E2D7',
  },

  aiSuggestionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1F4D3A',
    marginBottom: 6,
  },

  aiSuggestionText: {
    fontSize: 13,
    color: '#6B7280',
    lineHeight: 20,
  },
});